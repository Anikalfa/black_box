<?php
// Include database connection
include 'config/db.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $nid = $_POST['nid'];
    $dob = $_POST['dob'];
    $address = $_POST['address'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Handle file upload (profile picture)
    $profile_picture = '';
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $allowed_types = ['image/jpeg', 'image/png'];
        $file_type = $_FILES['profile_picture']['type'];
        $file_size = $_FILES['profile_picture']['size'];

        // Check if the file is of the allowed type
        if (in_array($file_type, $allowed_types)) {
            // Check file size (max 2MB)
            if ($file_size <= 2 * 1024 * 1024) {
                // Generate a unique filename for the image
                $file_name = uniqid('profile_') . '.' . pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
                $target_dir = 'uploads/';  // Ensure the 'uploads' folder exists
                $target_file = $target_dir . $file_name;

                // Move the uploaded file to the target directory
                if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_file)) {
                    $profile_picture = $file_name; // Save the filename in the database
                } else {
                    echo "Error: Failed to upload image.";
                    exit();
                }
            } else {
                echo "Error: File size exceeds the limit of 2MB.";
                exit();
            }
        } else {
            echo "Error: Only JPG and PNG files are allowed.";
            exit();
        }
    }

    // Check if email or phone already exists
    $sql = "SELECT id FROM users WHERE email = ? OR phone = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $phone);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "<p style='color:red;'>Email or Phone already registered!</p>";
    } else {
        // Register new user with profile picture
        $sql = "INSERT INTO users (name, email, phone, nid, dob, address, password, photo) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssss", $name, $email, $phone, $nid, $dob, $address, $password, $profile_picture);

        if ($stmt->execute()) {
            echo "Registration successful! <a href='login.php'>Login here</a>";
        } else {
            echo "Error: " . $stmt->error;
        }
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <link rel="stylesheet" href="css/style.css?v=1.0">
</head>
<body>

<!-- Registration Form Container -->
<div class="container">
    <h2>Register</h2>
    <form method="post" enctype="multipart/form-data">
        <input type="text" name="name" placeholder="Full Name" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="text" name="phone" placeholder="Phone Number" required><br>
        <input type="text" name="nid" placeholder="NID Number" required><br>
        <input type="date" name="dob" required><br>
        <textarea name="address" placeholder="Enter your address" required></textarea><br>
        <input type="password" name="password" placeholder="Password" required><br>

        <!-- Profile Picture Upload -->
        <label for="profile_picture">Upload Profile Picture (JPG/PNG):</label>
        <input type="file" name="profile_picture" accept="image/jpeg, image/png"><br><br>

        <button type="submit">Register</button>
    </form> 
</div>

</body>
</html>

