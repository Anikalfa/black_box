<?php
session_start();
include 'config/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sender = $_SESSION['user_id'];
    $receiver_id = $_POST['receiver'];
    $amount = floatval($_POST['amount']);
    $bkash_pin = $_POST['pin'];
    $reference = $_POST['reference'] ?? null;

        // Fetch sender's balance and stored PIN (password)
        $senderQuery = $conn->prepare("SELECT balance, password FROM users WHERE id = ?");
        $senderQuery->bind_param("i", $sender);
        $senderQuery->execute();
        $senderResult = $senderQuery->get_result();
    
        if ($senderResult->num_rows === 0) {
            echo "Error: Sender not found!";
            exit();
        }
    
        $senderData = $senderResult->fetch_assoc();
        $sender_balance = $senderData['balance'];
        $stored_pin = $senderData['password'];  // Assuming password is stored as PIN
    
        // Verify Bkash PIN (using password_verify instead of direct comparison)
        if (!password_verify($bkash_pin, $stored_pin)) {
            echo "Error: Incorrect Bkash PIN!";
            exit();
        }
    // Get receiver info
    $receiverQuery = $conn->prepare("SELECT phone, balance FROM users WHERE id = ?");
    $receiverQuery->bind_param("i", $receiver_id);
    $receiverQuery->execute();
    $receiverResult = $receiverQuery->get_result();

    if ($receiverResult->num_rows === 0) {
        echo "Error: Receiver not found!";
        exit();
    }

    $receiverData = $receiverResult->fetch_assoc();
    $receiver_phone = $receiverData['phone'];

    // Check balance
    if ($sender_balance < $amount) {
        echo "Error: Insufficient balance!";
        exit();
    }

    $transaction_id = uniqid("txn_");

    // Begin transaction
    $conn->begin_transaction();

    try {
        // Deduct sender balance
        $updateSender = $conn->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
        $updateSender->bind_param("di", $amount, $sender);
        $updateSender->execute();

        // Add to receiver
        $updateReceiver = $conn->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
        $updateReceiver->bind_param("di", $amount, $receiver_id);
        $updateReceiver->execute();

        // Insert transaction
        $insertTransaction = $conn->prepare("
            INSERT INTO transactions 
            (transaction_id, sender_id, receiver_id, receiver_type, amount, type, reference, date) 
            VALUES (?, ?, ?, 'user', ?, 'send_money', ?, NOW())
        ");
        $insertTransaction->bind_param("siids", $transaction_id, $sender, $receiver_id, $amount, $reference);
        $insertTransaction->execute();

        $conn->commit();

        // Update session balance
        $_SESSION['balance'] -= $amount;
        $_SESSION['message'] = "Money sent successfully to " . $receiver_phone;
        header("Location: dashboard.php");
        exit();

    } catch (Exception $e) {
        $conn->rollback();
        echo "Transaction failed: " . $e->getMessage();
    }
}
?>








