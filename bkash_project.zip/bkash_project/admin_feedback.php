<?php
session_start();
include 'config/db.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'super_admin'])) {
    echo "You must be logged in as an admin to view this page.";
    exit();
}

$sql = "SELECT f.id, u.name, f.message, f.created_at FROM feedback f JOIN users u ON f.user_id = u.id ORDER BY f.created_at DESC";
$result = $conn->query($sql);
$feedbacks = $result->fetch_all(MYSQLI_ASSOC);
$result->free();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Feedbacks</title>
</head>
<body>
<h1>User Feedback / Complaints</h1>

<table border="1" cellpadding="10">
    <thead>
        <tr>
            <th>ID</th><th>User</th><th>Message</th><th>Submitted At</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($feedbacks as $fb): ?>
        <tr>
            <td><?= $fb['id'] ?></td>
            <td><?= htmlspecialchars($fb['name']) ?></td>
            <td><?= htmlspecialchars($fb['message']) ?></td>
            <td><?= $fb['created_at'] ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<a href="admin_dashboard.php">Back to Dashboard</a>
</body>
</html>
