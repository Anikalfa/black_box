<?php
session_start();
include 'config/db.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'super_admin'])) {
    echo "Unauthorized access.";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user_id = $_POST['user_id'];

    // Optional: Prevent admins from deleting other admins/super_admins
    $check_role_sql = "SELECT role FROM users WHERE id = ?";
    $stmt = $conn->prepare($check_role_sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($target_role);
    $stmt->fetch();
    $stmt->close();

    if ($target_role === 'admin' && $_SESSION['role'] !== 'super_admin') {
        echo "Only super admin can delete other admins.";
        exit();
    }

    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);

    if ($stmt->execute()) {
        header("Location: admin_dashboard.php");
        exit();
    } else {
        echo "Error removing user.";
    }

    $stmt->close();
}
?>
