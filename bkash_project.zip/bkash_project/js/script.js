$(document).ready(function () {

    // Login
    $("#loginForm").submit(function (e) {
        e.preventDefault();
        let email = $("#email").val().trim();
        let password = $("#password").val().trim();

        if (!email || !password) {
            alert("Please fill in all fields.");
            return;
        }

        $.ajax({
            type: "POST",
            url: "backend/login.php",
            data: { email, password },
            dataType: "json",
            success: function (response) {
                if (response.status === "success") {
                    window.location.href = "dashboard.php";
                } else {
                    alert(response.message);
                }
            },
            error: function () {
                alert("Login failed. Please try again.");
            }
        });
    });

    // Registration
    $("#registerForm").submit(function (e) {
        e.preventDefault();
        let name = $("#name").val().trim();
        let email = $("#email").val().trim();
        let phone = $("#phone").val().trim();
        let password = $("#password").val().trim();

        if (!name || !email || !phone || !password) {
            alert("Please fill in all fields.");
            return;
        }

        $.ajax({
            type: "POST",
            url: "backend/register.php",
            data: { name, email, phone, password },
            dataType: "json",
            success: function (response) {
                if (response.status === "success") {
                    alert("Registration successful!");
                    window.location.href = "login.php";
                } else {
                    alert(response.message);
                }
            },
            error: function () {
                alert("Registration failed. Please try again.");
            }
        });
    });

    // Send Money
    $("#sendMoneyForm").submit(function (e) {
        e.preventDefault();

        const formData = $(this).serialize();

        $.ajax({
            type: "POST",
            url: "backend/send_money.php",
            data: formData,
            dataType: "json",
            success: function (response) {
                if (response.status === "success") {
                    alert(response.message);
                    window.location.href = "dashboard.php";
                } else {
                    alert(response.message);
                }
            },
            error: function () {
                alert("Failed to send money. Try again.");
            }
        });
    });

    // Receive Money
    $("#receiveMoneyForm").submit(function (e) {
        e.preventDefault();

        let sender = $("#sender_phone").val().trim();
        let amount = $("#receive_amount").val().trim();

        if (!sender || !amount) {
            alert("Please fill in all fields.");
            return;
        }

        $.ajax({
            type: "POST",
            url: "backend/receive_money.php",
            data: { sender, amount },
            dataType: "json",
            success: function (response) {
                if (response.status === "success") {
                    alert(response.message);
                    location.reload();
                } else {
                    alert(response.message);
                }
            },
            error: function () {
                alert("Error receiving money. Try again.");
            }
        });
    });

    // Load Transaction History
    function loadTransactions() {
        $.ajax({
            url: "backend/transactions.php",
            type: "GET",
            success: function (data) {
                $("#transactionHistory").html(data);
            },
            error: function () {
                $("#transactionHistory").text("Could not load transaction history.");
            }
        });
    }

    if ($("#transactionHistory").length > 0) {
        loadTransactions();
    }

    // Toggle show/hide for PIN field
    $("#togglePin").click(function () {
        const pinInput = $("#pin");
        const type = pinInput.attr("type");

        if (type === "password") {
            pinInput.attr("type", "text");
            $(this).text("Hide");
        } else {
            pinInput.attr("type", "password");
            $(this).text("Show");
        }
    });

});
document.addEventListener("DOMContentLoaded", () => {
    const searchInput = document.getElementById("searchInput");
    const userItems = document.querySelectorAll(".user-item");
    const receiverId = document.getElementById("receiverId");
    const selectedUserPreview = document.getElementById("selectedUserPreview");

    // Search functionality
    searchInput.addEventListener("input", () => {
        const filter = searchInput.value.toLowerCase();
        userItems.forEach(item => {
            const name = item.getAttribute("data-name").toLowerCase();
            const phone = item.getAttribute("data-phone").toLowerCase();
            item.style.display = (name.includes(filter) || phone.includes(filter)) ? "" : "none";
        });
    });

    // User selection
    userItems.forEach(item => {
        item.addEventListener("click", () => {
            userItems.forEach(i => i.classList.remove("selected"));
            item.classList.add("selected");

            const userId = item.getAttribute("data-id");
            const userName = item.getAttribute("data-name");
            const userPhone = item.getAttribute("data-phone");

            receiverId.value = userId;
            selectedUserPreview.innerText = `Sending to: ${userName} (${userPhone})`;
        });
    });
});
$('#receiver').select2({
    placeholder: "-- Choose Recipient --",
    minimumInputLength: 1,
    ajax: {
        url: 'search_users.php',
        dataType: 'json',
        delay: 250,
        data: function (params) {
            return {
                q: params.term
            };
        },
        processResults: function (data) {
            return {
                results: data.results
            };
        },
        cache: true
    }
});
