<?php
session_start();
require_once "config/db.php";

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get other users
$sql = "SELECT id, name, phone FROM users WHERE id != ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Money</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" />
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f7f8fa;
            padding: 20px;
            margin: 0;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            background: #fff;
            max-width: 500px;
            margin: 0 auto;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        label {
            margin-bottom: 8px;
            display: block;
            font-weight: 600;
            color: #555;
        }

        select, input[type="text"], input[type="number"], input[type="password"] {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #f9f9f9;
            box-sizing: border-box;
        }

        select:focus, input[type="text"]:focus, input[type="number"]:focus, input[type="password"]:focus {
            border-color: #4CAF50;
            outline: none;
            background-color: #fff;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #4CAF50;
            color: #fff;
            font-size: 18px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        a {
            text-decoration: none;
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #4CAF50;
            font-size: 16px;
        }

        .search-results {
            padding: 8px;
            background: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 8px;
            max-height: 150px;
            overflow-y: auto;
            margin-top: 10px;
        }

        .search-result {
            cursor: pointer;
            padding: 8px;
            background: #fff;
            border-bottom: 1px solid #ddd;
        }

        .search-result:hover {
            background-color: #f1f1f1;
        }


        /* Ensure that the select2 dropdown appears outside the input box */
        .select2-container--default .select2-selection--single {
            z-index: 1000; /* Ensures the dropdown appears above other elements */
        }

        /* Adjust the dropdown positioning */
        .select2-container--default .select2-dropdown {
            position: absolute;
            z-index: 9999; /* Ensures the dropdown is on top of other content */
        }

    </style>
</head>
<body>

<h2>Send Money</h2>

<form action="send_money_process.php" method="POST">
    <label for="search">Select Recipient (Name or Phone):</label>
    <select name="receiver" id="receiver" required>
        <option value="">-- Choose Recipient --</option>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <option value="<?= $row['id'] ?>" data-phone="<?= $row['phone'] ?>">
                <?= htmlspecialchars($row['name']) ?> (<?= htmlspecialchars($row['phone']) ?>)
            </option>
        <?php } ?>
    </select>
   
    <select>
    <label for="amount">Amount:</label>
    <input type="number" name="amount" id="amount" placeholder="Enter amount" required step="0.01">

    <label for="reference">Reference (Optional):</label>
    <input type="text" name="reference" id="reference" placeholder="Note or reason">

    <label for="pin">Enter Your bKash PIN:</label>
    <input type="password" id="pin" name="pin" required><br><br>

    <button type="submit">Send Money</button>
    <a href="dashboard.php">← Back to Dashboard</a>
</form>

<!-- jQuery and Select2 -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        // Initialize Select2 for better dropdown styling
        $('#receiver').select2({
            placeholder: "-- Choose Recipient --",
            allowClear: true
        });

        // When a recipient is selected, display the phone number in the input field
        $('#receiver').on('change', function() {
            const selectedOption = $(this).find('option:selected');
            const phone = selectedOption.data('phone');
            const name = selectedOption.text();
            console.log('Selected: ', name, phone);  // Debugging
        });
    });
</script>

</body>
</html>