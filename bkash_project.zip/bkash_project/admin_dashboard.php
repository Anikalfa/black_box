<?php
session_start();
include 'config/db.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'super_admin'])) {
    echo "You must be logged in as an admin to access this page.";
    exit();
}

$role = $_SESSION['role'];

// Fetch all users
$sql = "SELECT id, name, email, phone, nid, dob, address, balance FROM users";
$result = $conn->query($sql);
$users = $result->fetch_all(MYSQLI_ASSOC);
$result->free();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/style.css">

</head>
<body>

<h1>Welcome, <?= ucfirst($role) ?></h1>

<nav>
    <ul>
        
        <li><a href="admin_view_feedback.php">View Feedback</a></li>
        <li><a href="view_transactions.php">View Transactions</a></li>
        <?php if ($role === 'super_admin'): ?>
            <li><a href="admin_create.php">Create Admin</a></li>
            <!-- Add other super admin features -->
        <?php endif; ?>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>

<h2>All Users:</h2>
<table border="1" cellpadding="10">
    <thead>
        <tr>
            <th>ID</th><th>Name</th><th>Email</th><th>Phone</th>
            <th>NID</th><th>DOB</th><th>Address</th><th>Balance</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($users as $user): ?>
        <tr>
            <td><?= htmlspecialchars($user['id']) ?></td>
            <td><?= htmlspecialchars($user['name']) ?></td>
            <td><?= htmlspecialchars($user['email']) ?></td>
            <td><?= htmlspecialchars($user['phone']) ?></td>
            <td><?= htmlspecialchars($user['nid']) ?></td>
            <td><?= htmlspecialchars($user['dob']) ?></td>
            <td><?= htmlspecialchars($user['address']) ?></td>
            <td>৳<?= number_format($user['balance'], 2) ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

</body>
</html>

