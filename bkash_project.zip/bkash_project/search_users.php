<?php
session_start();
require_once 'config/db.php';

// Set content type as JSON
header('Content-Type: application/json');

// If the user is not logged in, return empty results
if (!isset($_SESSION['user_id'])) {
    echo json_encode([]);
    exit();
}

// Get the search query parameter
$search = $_GET['q'] ?? '';
$user_id = $_SESSION['user_id'];  // The logged-in user's ID

// Validate input to prevent SQL injection
$search = $conn->real_escape_string($search);

// Prepare the SQL query
$sql = "SELECT id, name, phone FROM users WHERE id != ? AND (name LIKE ? OR phone LIKE ?) LIMIT 10";
$stmt = $conn->prepare($sql);
$likeSearch = '%' . $search . '%'; // Use LIKE for searching

// Bind the parameters and execute the query
$stmt->bind_param("iss", $user_id, $likeSearch, $likeSearch);
$stmt->execute();
$result = $stmt->get_result();

$users = [];

// Fetch the results and format them
while ($row = $result->fetch_assoc()) {
    $users[] = [
        'id' => $row['id'],
        'text' => $row['name'] . ' (' . $row['phone'] . ')'
    ];
}

// Debugging output
if (empty($users)) {
    error_log("No users found for search query: " . $search); // Debugging
}

// Return the results as a JSON response
echo json_encode(['results' => $users]);
?>
