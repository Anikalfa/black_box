<?php
session_start();
include 'config/db.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "Error: Unauthorized access!";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $phone_number = $_POST['phone_number'];
    $amount = floatval($_POST['amount']);
    $operator = $_POST['operator']; // Capturing the operator
    $entered_pin = $_POST['pin'];  // Capturing the entered bKash PIN (Password in this case)

    // Fetch user's balance and stored PIN (password) from the database
    $userQuery = $conn->prepare("SELECT balance, password FROM users WHERE id = ?");
    $userQuery->bind_param("i", $user_id);
    $userQuery->execute();
    $userResult = $userQuery->get_result();

    if ($userResult->num_rows === 0) {
        echo "Error: User not found!";
        exit();
    }

    $userData = $userResult->fetch_assoc();
    $user_balance = $userData['balance'];
    $stored_password = $userData['password'];  // Fetching the stored hashed password (PIN)

    // Verify the entered bKash PIN (which is the password in this case)
    if (!password_verify($entered_pin, $stored_password)) {
        echo "❌ Error: Incorrect bKash PIN (password)!";
        exit();
    }

    // Check if the user has sufficient balance for the recharge
    if ($user_balance < $amount) {
        echo "❌ Error: Insufficient balance!";
        exit();
    }

    // Deduct the amount from user's balance
    $new_balance = $user_balance - $amount;
    $updateBalanceQuery = $conn->prepare("UPDATE users SET balance = ? WHERE id = ?");
    $updateBalanceQuery->bind_param("di", $new_balance, $user_id);
    $updateBalanceQuery->execute();

    // Insert the mobile recharge record into the database
    $insertRechargeQuery = $conn->prepare("INSERT INTO mobile_recharge (user_id, phone_number, amount, operator) VALUES (?, ?, ?, ?)");
    $insertRechargeQuery->bind_param("isss", $user_id, $phone_number, $amount, $operator);
    $insertRechargeQuery->execute();

    // Generate a unique transaction ID
    $transaction_id = uniqid("txn_");

    // Insert the transaction record for recharge
    $insertTransactionQuery = $conn->prepare("INSERT INTO transactions (transaction_id, sender_id, receiver_id, amount, type, description) VALUES (?, ?, ?, ?, 'recharge', ?)");
    $insertTransactionQuery->bind_param("siids", $transaction_id, $user_id, $user_id, $amount, $operator);
    $insertTransactionQuery->execute();

    echo "✅ Mobile recharge of " . number_format($amount, 2) . " for " . htmlspecialchars($operator) . " was successful! Your new balance is: ৳" . number_format($new_balance, 2);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mobile Recharge</title>
    <link rel="stylesheet" href="css/style.css?v=1.0">
</head>
<body>

<h2>Mobile Recharge</h2>

<form method="post">
    <label for="phone_number">Recipient Phone Number:</label>
    <input type="text" name="phone_number" required><br><br>

    <label for="amount">Amount:</label>
    <input type="number" name="amount" required><br><br>

    <label for="operator">Select Operator:</label>
    <select name="operator" required>
        <option value="">-- Select Operator --</option>
        <option value="Airtel">Airtel</option>
        <option value="Robi">Robi</option>
        <option value="Grameenphone">Grameenphone</option>
        <option value="Banglalink">Banglalink</option>
    </select><br><br>

    <!-- Bkash PIN -->
    <label for="pin">Enter Your PIN:</label><br>
    <input type="password" id="pin" name="pin" required>
    <button type="button" id="togglePin" style="margin-left: 5px;">Show</button><br><br>

    <button type="submit">Recharge</button>
    
    <br><br>
    <a href="dashboard.php">Go Back to Dashboard</a>
</form>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        $("#togglePin").click(function () {
            const pinInput = $("#pin");
            const currentType = pinInput.attr("type");

            if (currentType === "password") {
                pinInput.attr("type", "text");
                $(this).text("Hide");
            } else {
                pinInput.attr("type", "password");
                $(this).text("Show");
            }
        });
    });
</script>
</body>
</html>

