<?php
session_start();
include 'config/db.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'super_admin'])) {
    echo "Unauthorized access.";
    exit();
}

$sql = "SELECT * FROM transactions ORDER BY date DESC";
$result = $conn->query($sql);
$transactions = $result->fetch_all(MYSQLI_ASSOC);
$result->free();
?>

<!DOCTYPE html>
<html>
<head>
    <title>All Transactions</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<h1>All Transactions</h1>
<a href="admin_dashboard.php">← Back to Dashboard</a>

<table border="1" cellpadding="10">
    <thead>
        <tr>
            <th>ID</th><th>Sender ID</th><th>Receiver ID</th>
            <th>Type</th><th>Amount</th><th>Date</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($transactions as $tx): ?>
        <tr>
            <td><?= $tx['id'] ?></td>
            <td><?= $tx['sender_id'] ?></td>
            <td><?= $tx['receiver_id'] ?></td>
            <td><?= $tx['type'] ?></td>
            <td>৳<?= number_format($tx['amount'], 2) ?></td>
            <td><?= $tx['date'] ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

</body>
</html>
