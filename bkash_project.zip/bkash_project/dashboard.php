<?php
session_start();
include 'config/db.php'; // Ensure the path is correct

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "You must be logged in to view this page.";
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user details from the database
$sql = "SELECT name, balance, photo FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $user_name = htmlspecialchars($row['name']);
    $balance = number_format($row['balance'], 2);
    $profile_picture = $row['photo']; // Get the profile picture filename
} else {
    echo "Error: User not found.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/style.css?v=1.0"> <!-- Link to external CSS file -->
</head>
<body>

<!-- Header Section -->
<header class="header">
    <div class="logo">
        <img src="logo.png" alt="Logo"> <!-- Use your logo here -->
    </div>
    <nav class="nav">
        <a href="#">Services</a>
        <a href="#">Offers</a>
        <a href="#">About Us</a>
        <a href="#">Help</a>
        <a href="#">Career</a>
    </nav>
    <div class="lang">
        <button>English</button> <!-- Language toggle -->
    </div>
</header>

<!-- Hero Section -->
<section class="hero">
    <div class="hero-content">
        <h1>Welcome, <?php echo $user_name; ?>!</h1>
        <p>Your current balance is: ৳<?php echo $balance; ?></p>
    </div>

    <!-- Profile Picture Section -->
    <div class="profile-section">
        <?php
        // Display the profile picture if uploaded, else show a default image
        if ($profile_picture) {
            echo "<img src='uploads/" . $profile_picture . "' alt='Profile Picture' class='profile-picture'>";
        } else {
            echo "<img src='uploads/default.jpg' alt='Default Profile Picture' class='profile-picture'>";
        }
        ?>
    </div>
</section>

<!-- Action Buttons Section -->
<section class="action-buttons">
    <a href="send_money.php" class="btn">Send Money</a>
    <a href="transaction_history.php" class="btn">Transaction History</a>
    <a href="add_money_button.php" class="btn">Add Money</a>
    <a href="mobile_recharge.php" class="btn">Mobile Recharge</a>
    <a href="payment.php" class="btn">Payment</a>
    <a href="pay_bill.php" class="btn">Pay Bill</a>
    <a href="bkash_to_bank.php" class="btn">LenDen to Bank Transfer</a>
    <a href="cash_out.php" class="btn">Cash Out</a>
    <a href="feedback.php" class="btn">Give Feedback</a>
    <a href="logout.php" class="btn logout-btn">Logout</a>
</section>

</body>
</html>



