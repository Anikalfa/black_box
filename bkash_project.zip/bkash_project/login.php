<?php
session_start();
include 'config/db.php'; // Make sure this path is correct

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Look up the user by email
    $sql = "SELECT id, name, password, balance FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    // If we found a row, verify the password
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $name, $hashed_password, $balance);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            // Login success
            $_SESSION['user_id']    = $id;
            $_SESSION['user_name']  = $name;
            $_SESSION['balance']    = $balance;
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid password!";
        }
    } else {
        $error = "Email not found!";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Login - bKash Clone</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

  <h2>Login</h2>

  <?php if (!empty($error)): ?>
    <p style="color:red;"><?= htmlspecialchars($error) ?></p>
  <?php endif; ?>

  <form id="loginForm" method="post" action="login.php">
    <div>
      <label for="email">Email:</label><br>
      <input type="email" id="email" name="email" placeholder="Email" required>
    </div>
    <div style="margin-top:8px;">
      <label for="password">Password:</label><br>
      <input type="password" id="password" name="password" placeholder="Password" required>
      <button type="button" id="toggleLoginPwd" style="margin-left:5px;">Show</button>
    </div>
    <div style="margin-top:16px;">
      <button type="submit">Login</button>
    </div>
  </form>

  <p style="margin-top:12px;">
    <a href="register.php">Don't have an account? Register here.</a><br>
    <a href="reset_password.php">Forgot/Reset Password?</a>
  </p>

  <!-- Include jQuery and then our toggle script -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(function(){
      $("#toggleLoginPwd").on("click", function(){
        const pwd = $("#password");
        if (pwd.attr("type")==="password") {
          pwd.attr("type","text");
          $(this).text("Hide");
        } else {
          pwd.attr("type","password");
          $(this).text("Show");
        }
      });
    });
  </script>

</body>
</html>
