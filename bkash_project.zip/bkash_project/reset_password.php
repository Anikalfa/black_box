<!-- reset_password.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Password Reset</title>
</head>
<body>

<h2>Reset Password</h2>
<form method="POST" action="reset_password_action.php">
    <label>Email:</label><br>
    <input type="email" name="email" required><br><br>

    <label>New Password:</label><br>
    <input type="password" id="password" name="password" placeholder="Password" required>
    <button type="button" id="toggleLoginPwd" style="margin-left:5px;">Show</button>
    </div>
    <div style="margin-top:16px;">
      <button type="submit">Login</button>
    </div>
</form>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(function(){
      $("#toggleLoginPwd").on("click", function(){
        const pwd = $("#password");
        if (pwd.attr("type")==="password") {
          pwd.attr("type","text");
          $(this).text("Hide");
        } else {
          pwd.attr("type","password");
          $(this).text("Show");
        }
      });
    });
  </script>
</body>
</html>
